# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 16:49:21 2021

@author: EFG
"""
import pygame 
import animation

# on crée une classe pour le joueur 
class Player(animation.AnimateSprite):
    
    def __init__(self, game):
        super().__init__("Cat")
        self.game = game
        self.health = 100
        self.max_health= 100
        self.attack = 10
        self.velocity = 4
        self.image = pygame.image.load('images/Cat.png')
        self.image = pygame.transform.scale(self.image, (100, 100))
        self.rect = self.image.get_rect() 
        self.rect.x = 500
        self.rect.y = 500
        
    def damage(self, amount):
        if self.health - amount > amount:
            self.health -= amount
        else:
            #si le joueur n'a plus de point de vie
            self.game.game_over()
            
    def update_health_bar(self, surface):
        #dessiner notre barre de vie
        pygame.draw.rect(surface, (60, 63, 60), [self.rect.x , self.rect.y - 20, self.max_health, 5])
        pygame.draw.rect(surface, (255, 255, 255), [self.rect.x , self.rect.y - 20, self.health, 5])    
    
    def update_animation(self):
        self.animate()
    
    def move_right(self):
        if self.game.check_collision(self, self.game.all_monsters):
            self.laser_event.game.sound_manager.play('damage')
            self.game.player.damage(100)
        #si joueur n'estpas en collision avec l'ennemi            
        if not self.game.check_collision(self, self.game.all_monsters):
            self.rect.x += self.velocity

    def move_left(self):
        if self.game.check_collision(self, self.game.all_monsters):
            self.laser_event.game.sound_manager.play('damage')
            self.game.player.damage(100)
        #si le joueur n'est pas en collision avec le monstre 
        if not self.game.check_collision(self, self.game.all_monsters):
            self.rect.x -= self.velocity
        
    def move_up(self):
        if self.game.check_collision(self, self.game.all_monsters):
            self.laser_event.game.sound_manager.play('damage')
            self.game.player.damage(100)  
        #si le joueur n'est pas en collision avec le monstre 
        if not self.game.check_collision(self, self.game.all_monsters):
            self.rect.y -= self.velocity

    def move_down(self):
        if self.game.check_collision(self, self.game.all_monsters):
            self.laser_event.game.sound_manager.play('damage')
            self.game.player.damage(100)  
        #si le joueur n'est pas en collision avec le monstre 
        if not self.game.check_collision(self, self.game.all_monsters):
            self.rect.y += self.velocity