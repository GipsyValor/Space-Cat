# -*- coding: utf-8 -*-
"""
Created on Mon Dec  7 22:41:23 2020

@author: EFG
"""

import pygame
import math
from pygame.locals import *
from game import Game
pygame.init()
pygame.display.init()

clock = pygame.time.Clock()
FPS = 180

#ouvrir une fenêtre 
pygame.display.set_caption("Space Cat")
screen=pygame.display.set_mode((1080,720), RESIZABLE)

#Icone
icone = pygame.image.load("images/icone.png")
pygame.display.set_icon(icone)


#charger la banniére du jeu
banner = pygame.image.load('images/title.png').convert_alpha()
banner = pygame.transform.scale(banner, (400,230))
banner_rect = banner.get_rect()
banner_rect.x = math.ceil(screen.get_width() /3.19)
banner_rect.y = math.ceil(screen.get_height() /8)

#charger le bouton pour lancer le jeu
play_button = pygame.image.load('images/start.png').convert_alpha()
play_button = pygame.transform.scale(play_button, (250, 90))
play_button_rect = play_button.get_rect()
play_button_rect.x = math.ceil(screen.get_width() /2.67)
play_button_rect.y = math.ceil(screen.get_height() /1.85)

#charger le bouton pour lancer le jeu
continue_button = pygame.image.load('images/continue.png').convert_alpha()
continue_button = pygame.transform.scale(continue_button, (200, 60))
continue_button_rect = continue_button.get_rect()
continue_button_rect.x = math.ceil(screen.get_width() /1.3)
continue_button_rect.y = math.ceil(screen.get_height() /1.2)

quit_button = pygame.image.load('images/quit.png').convert_alpha()
quit_button = pygame.transform.scale(quit_button, (130, 50))
quit_button_rect = quit_button.get_rect()
quit_button_rect.x = 10
quit_button_rect.y = 10

game_over_banner = pygame.image.load('images/gameover.png').convert_alpha()
game_over_banner = pygame.transform.scale(game_over_banner, (500, 80))
game_over_banner_rect = game_over_banner.get_rect()
game_over_banner_rect.x = math.ceil(screen.get_width() /3.75)
game_over_banner_rect.y = math.ceil(screen.get_height() /4)

credits_button = pygame.image.load('images/credits.png').convert_alpha()
credits_button = pygame.transform.scale(credits_button, (225, 60))
credits_button_rect = credits_button.get_rect()
credits_button_rect.x = math.ceil(screen.get_width() /1.3)
credits_button_rect.y = math.ceil(screen.get_height() /1.15)

gameby = pygame.image.load('images/gameby.png').convert_alpha()
gameby = pygame.transform.scale(gameby, (500, 250))
gameby_rect = credits_button.get_rect()
gameby_rect.x = math.ceil(screen.get_width() /3.75)
gameby_rect.y = math.ceil(screen.get_height() /4)


death = pygame.image.load('images/death.png').convert_alpha()
death = pygame.transform.scale(death, (135, 135))
death_rect = death.get_rect()
death_rect.x = math.ceil(screen.get_width() /2.40)
death_rect.y = math.ceil(screen.get_height() /2.2)

running = True 

#importer l'arriére plan

background = pygame.image.load('images/background.gif').convert()
background = pygame.transform.scale(background, (1200,750))

game_over_background = pygame.image.load('images/background.gif').convert()
game_over_background = pygame.transform.scale(game_over_background, (1080,720))

#charger le jeu
game = Game()

#boucle tant que running est vrai la fenêtre est ouverte
while running:
    
    screen.fill((0, 0, 0))
    
    #appliquer l'arriére plan
    screen.blit(background, (0, 0))

    #vérifier si notre jeu a commmencé ou non
    if game.is_playing:
        #déclencher les instructions de la partie
        game.update(screen)
        
    elif game.is_game_over :
        screen.fill((0, 0, 0))
        screen.blit(game_over_background, (0, 0))
        screen.blit(death, death_rect)
        screen.blit(game_over_banner, game_over_banner_rect)
        screen.blit(continue_button, continue_button_rect)
        screen.blit(quit_button, quit_button_rect)
        
    elif game.credits :
        screen.fill((0, 0, 0))
        screen.blit(game_over_background, (0, 0))
        screen.blit(gameby, gameby_rect)
        screen.blit(quit_button, quit_button_rect)
    
    # vérifier si le jeu n'a pas commencé$
    else :
        #ajout de l'écran de bienvenue
        screen.blit(banner, banner_rect)
        screen.blit(play_button, play_button_rect)
        screen.blit(credits_button, credits_button_rect)
        #game.sound_manager.play('menu')
    
    #on met à jour la fenêtre
    pygame.display.flip()
            
    #si la personne  ferme cette fenêtre 
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
            pygame.quit()
            print("Fermeture du jeu")
        #détecter si un joueur lâche une touche du clavier
        elif event.type == pygame.KEYDOWN:
            game.pressed[event.key] = True
        elif event.type == pygame.KEYUP:
            game.pressed[event.key] = False
            
        elif event.type == pygame.MOUSEBUTTONDOWN :
            
            if  credits_button_rect.collidepoint(event.pos):
                game.credit()
            
            elif quit_button_rect.collidepoint(event.pos):
                game.creditFalse()
                game.game_over_False()
            
            #vérification pour savoir si la souris est en collision avec le bouton jouer
            elif play_button_rect.collidepoint(event.pos):
                #mettre le jeu en mode "lancé"
                game.start()
                
            elif continue_button_rect.collidepoint(event.pos):
                 game.start()
     #Fixer le nombre de FPS
    clock.tick(FPS)