# -*- coding: utf-8 -*-
"""
Created on Sat Mar 13 16:45:00 2021

@author: labra
"""

import pygame

class SoundManager:
    
    def __init__(self):
        self.sounds = {
            'menu': pygame.mixer.Sound("images/sounds/music_menu.mp3"),
            'start': pygame.mixer.Sound("images/sounds/music_in_game.mp3"),
            'game_over': pygame.mixer.Sound("images/sounds/tiger_attack.mp3"),
            'laser': pygame.mixer.Sound("images/sounds/laser.mp3"),
            'damage': pygame.mixer.Sound("images/sounds/cat_damage.mp3"),
            }
    
    def play(self, name):
        self.sounds[name].play()