# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 21:52:47 2021

@author: labra
"""

import pygame
import random

class PreLaser2(pygame.sprite.Sprite):
    
    def __init__(self, laser_event):
        super().__init__()
        #définir l'image du laser
        self.image = pygame.image.load('images/laser3.png')
        self.image = pygame.transform.scale(self.image, (200, 50))
        self.rect = self.image.get_rect() 
        self.velocity = 2.8
        self.laser_event =laser_event
        self.rect.x = 1000
        self.rect.y = random.randint(200,600)


    def remove(self):
        self.laser_event.all_prelasers2.remove(self)
        
    def aléa2(self):
        self.rect.y = random.randint(200,500)
        
    def fall2(self):
        self.rect.x -= self.velocity
        if self.rect.x <= 0:
            self.remove()
            
        if self.laser_event.game.check_collision(self, self.laser_event.game.all_players):
            self.remove()
            self.laser_event.game.player.damage(30)  
        
