# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 16:49:19 2021

@author: EFG
"""

import pygame
from monster import Monster
from player import Player
from laser_event import LaserFallEvent
from laser import Laser
from laser2 import Laser2
from sounds import SoundManager

class Game:
    
    def __init__(self):
        #définir si le jeu a commencé ou non
        self.is_playing = False
        self.is_game_over = False
        self.credits = False
        #generer le joueur
        self.all_players = pygame.sprite.Group()
        self.player = Player(self)
        self.all_players.add(self.player)
        self.sound_manager = SoundManager()
        #générer l'événement
        self.laserr = Laser(self)
        self.laserr2 = Laser2(self)
        self.laser_event = LaserFallEvent(self)
        #groupe de monstre pour permettre la comparaison pour les collisions
        self.all_monsters = pygame.sprite.Group()
        #mettre le score à 0
        self.score = 0
        self.pressed = {}
        


    def update(self, screen):
        
        self.laserr2.update_difficulty2()
        
        self.laserr.update_difficulty()
        
        self.player.update_animation()
        
        for monster in self.all_monsters:
            monster.update_animation()
        
        for prelaser in self.laser_event.all_prelasers1:
            prelaser.fall2()
        
        for prelaser2 in self.laser_event.all_prelasers2:
            prelaser2.fall2()
            
        for laser in self.laser_event.all_lasers1:
            laser.fall()
        
        for laser2 in self.laser_event.all_lasers2:
            laser2.fall()
        
        self.laser_event.update_bar()
        
        self.player.update_health_bar(screen)
        
        
        #appliquer l'image du joueur 
        self.all_players.draw(screen)
        
        #on applique l'image de l'ennemi
        self.all_monsters.draw(screen)
        
        self.laser_event.all_lasers1.draw(screen)
        
        self.laser_event.all_lasers2.draw(screen)
        
        self.laser_event.all_prelasers1.draw(screen)
        
        self.laser_event.all_prelasers2.draw(screen)
        
        if self.pressed.get(pygame.K_RIGHT) and self.player.rect.x + self.player.rect.width < screen.get_width():
            self.player.move_right()
        elif self.pressed.get(pygame.K_LEFT) and self.player.rect.x > 0:
           self.player.move_left()
        elif self.pressed.get(pygame.K_UP) and self.player.rect.y  > 0:
            self.player.move_up()
        elif self.pressed.get(pygame.K_DOWN) and self.player.rect.y + self.player.rect.height < screen.get_height():
            self.player.move_down()
        
    def spawn_monster(self):
        monster = Monster(self)
        self.all_monsters.add(monster)

        
    def start(self):
        self.is_playing = True
        self.spawn_monster()
        #self.sound_manager.play('start')
        
    def credit(self):
        self.credits = True
    
    def creditFalse(self):
        self.credits = False

    def game_over(self):
        #remettre le jeu à neuf, remetre l'ennemi, remetre le joueur
        self.is_game_over = True
        self.sound_manager.play('game_over')
        self.player.rect.x = 500
        self.player.rect.y = 400
        self.all_monsters = pygame.sprite.Group()
        self.laser_event.all_lasers1 = pygame.sprite.Group()
        self.laser_event.all_lasers2 = pygame.sprite.Group()
        self.laser_event.all_prelasers1 = pygame.sprite.Group()
        self.laser_event.all_prelasers2 = pygame.sprite.Group()
        self.laser_event.reset_prepercent()
        self.laser_event.reset_percent()
        self.player.health = 100
        self.is_playing = False
        self.score = 0

    def game_over_False(self):
        self.is_game_over = False
        
    def check_collision(self, sprite, group):
        return pygame.sprite.spritecollide(sprite, group, False, pygame.sprite.collide_mask)
    




        