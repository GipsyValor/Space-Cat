# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 17:42:12 2021

@author: labra
"""

import pygame
import random
from prelaser2 import PreLaser2


class Laser2(pygame.sprite.Sprite):
    
    def __init__(self, laser_event):
        super().__init__()
        #définir l'image du laser
        self.image = pygame.image.load('images/laser1.png')
        self.image = pygame.transform.scale(self.image, (200, 50))
        self.rect = self.image.get_rect()
        self.percen2 = 0
        self.percen2_speed = 5
        self.velocity =2.5
        self.prelaser2 = PreLaser2(self)
        self.laser_event = laser_event
        self.rect.x = 0
        self.rect.y = random.randint(200,600)



    def remove(self):
        self.laser_event.all_lasers2.remove(self)

        
    def add_percen2(self):
        self.percen2 += self.percen2_speed /110


    def difficulty2(self):
        if self.percen2 < 150.6:
            self.velocity = 3
        elif self.percen2 >= 150.6 and self.percen2 <= 602.2:
            self.velocity = 3
        elif self.percen2 >= 602.2:
            self.velocity = 6

   
    def update_difficulty2(self):
        self.add_percen2()
        
        #appel de la méthode pour essayer de déclencher l'augmentation de difficulté
        self.difficulty2()

    def fall(self):
        self.rect.x += self.velocity
        if self.rect.x >= 1000:
            self.remove()
            
        if self.laser_event.game.check_collision(self, self.laser_event.game.all_players):
            self.remove()
            self.laser_event.game.sound_manager.play('damage')
            self.laser_event.game.player.damage(30)