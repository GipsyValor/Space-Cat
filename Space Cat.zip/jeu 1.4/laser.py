# -*- coding: utf-8 -*-
"""
Created on Fri Feb  5 16:27:58 2021

@author: labra
"""

import pygame
import random
from prelaser import PreLaser

class Laser(pygame.sprite.Sprite):
    
    def __init__(self, laser_event):
        super().__init__()
        #définir l'image du laser
        self.image = pygame.image.load('images/laser2.png')
        self.image = pygame.transform.scale(self.image, (50, 200))
        self.rect = self.image.get_rect() 
        self.prelaser = PreLaser(self)
        self.laser_event = laser_event
        self.percen = 0
        self.percen_speed = 5
        self.velocity = 2.5
        self.rect.x = random.randint(0,1020)
        self.rect.y = 0

    def add_percen(self):
        self.percen += self.percen_speed /110

    
    def difficulty(self):
        if self.percen < 150.6:
            self.velocity = 3
        elif self.percen >= 150.6 and self.percen <= 602.2:
            self.velocity = 3
        elif self.percen >= 602.2:
            self.velocity = 6
        
    
    def update_difficulty(self):
        
        self.add_percen()
        
        #appel de la méthode pour essayer de déclencher les lasers
        self.difficulty()

    def remove(self):
        self.laser_event.all_lasers1.remove(self)
        
    
    def fall(self):
        self.rect.y += self.velocity
        if self.rect.y >= 625:
            self.remove()
            
        if self.laser_event.game.check_collision(self, self.laser_event.game.all_players):
            self.remove()
            self.laser_event.game.sound_manager.play('damage')
            self.laser_event.game.player.damage(30)