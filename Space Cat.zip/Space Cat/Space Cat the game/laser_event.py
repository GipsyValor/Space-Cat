# -*- coding: utf-8 -*-
"""
Created on Fri Feb  5 16:49:25 2021

@author: labra
"""


import pygame
from laser import Laser
from laser2 import Laser2
from prelaser import PreLaser
from prelaser2 import PreLaser2
    
    
class LaserFallEvent:
    
    def __init__(self, game):
        self.percent = 0
        self.percent_speed = 20
        self.prepercent = 0
        self.prepercent_speed = 20
        #définir un groupe de sprite pour stocker les prelaser
        self.all_lasers1 = pygame.sprite.Group()
        self.all_lasers2 = pygame.sprite.Group()
        #définir un groupe de sprite pour stocker les prelaser
        self.all_prelasers1 = pygame.sprite.Group()
        self.all_prelasers2 = pygame.sprite.Group()
        self.game = game

    def add_percent(self):
        self.percent += self.percent_speed /150
        self.prepercent += self.prepercent_speed /150
        
    def is_full_loaded2(self):
        return self.prepercent >= 150
        
    def is_full_loaded(self):
        return self.percent >= 100
    
    def reset_percent(self):
        self.percent = 0
        
    def reset_prepercent(self):
        self.prepercent = 0
        
    def attempt_fall(self):
        if self.is_full_loaded2():
            self.laser_fall2()
            self.game.sound_manager.play('laser')
            self.reset_prepercent()
            
        if self.is_full_loaded():
            print("Lasers !!")
            self.laser_fall()
            self.game.sound_manager.play('laser')
            self.reset_percent()
        
    def laser_fall2(self):
        #faire apparaître un premier laser
        self.all_prelasers1.add(PreLaser(self))
        #faire apparaître un deuxiéme laser
        self.all_prelasers2.add(PreLaser2(self))

    def laser_fall(self):
        #faire apparaître un premier laser
        self.all_lasers1.add(Laser(self))
        #faire apparaître un deuxiéme laser
        self.all_lasers2.add(Laser2(self))
        


    def update_bar(self):
        
        self.add_percent()
        
        #appel de la méthode pour essayer de déclencher les lasers
        self.attempt_fall()