# -*- coding: utf-8 -*-
"""
Created on Sat Feb 27 21:52:45 2021

@author: labra
"""

import pygame
import random

class PreLaser(pygame.sprite.Sprite):
    
    def __init__(self, laser_event):
        super().__init__()
        #définir l'image du laser
        self.image = pygame.image.load('images/laser4.png')
        self.image = pygame.transform.scale(self.image, (50, 200))
        self.rect = self.image.get_rect() 
        self.velocity = 2.8
        self.laser_event = laser_event
        self.rect.x = random.randint(0,1020)
        self.rect.y = 625

    
    def remove(self):
        self.laser_event.all_prelasers1.remove(self)
        
    def aléa(self):
        a = random.randint(0,1000)
        self.rect.x = a
        
    def fall2(self):
        self.rect.y -= self.velocity
        if self.rect.y <= 0:
            self.remove()
            
        if self.laser_event.game.check_collision(self, self.laser_event.game.all_players):
            self.remove()
            self.laser_event.game.player.damage(30)