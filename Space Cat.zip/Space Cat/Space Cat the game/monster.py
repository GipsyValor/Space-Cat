# -*- coding: utf-8 -*-
"""
Created on Sun Jan 31 16:49:27 2021

@author: EFG
"""
import pygame 
import animation

#on créée une classe pour le le monstre

class Monster(animation.AnimateSprite):
    
    def __init__(self, game):
        super().__init__("Tiger")
        self.game = game
        self.health = 100
        self.max_health = 100
        self.attack = 25
        self.image = pygame.image.load('images/Tiger.png')
        self.image = pygame.transform.scale(self.image, (125, 125))
        self.rect = self.image.get_rect()
        self.rect.x = 450

    
    def forward(self):
        if not self.game.check_collision(self, self.game.all_players):
            self.rect.x = 450
        else :
           self.game.player.damage(self.attack)
           
    def update_animation(self):
        self.animate()